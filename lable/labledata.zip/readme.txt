经度 纬度 沿轨距离 高程 跨规距离 置信度 水体标注（水面为1 水底为2 噪声为0）
https://github.com/wangzijia06/Manually-labeled-water-depth-data-in-the-South-China-Sea